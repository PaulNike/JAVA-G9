package com.codigo.patron_adapter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatronAdapterApplicationTests {

	@Test
	void contextLoads() {
	}

}
