package com.codigo.patron_adapter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatronAdapterApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatronAdapterApplication.class, args);
	}

}
