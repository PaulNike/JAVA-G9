package com.codigo.patron_strategy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatronStrategyApplicationTests {

	@Test
	void contextLoads() {
	}

}
