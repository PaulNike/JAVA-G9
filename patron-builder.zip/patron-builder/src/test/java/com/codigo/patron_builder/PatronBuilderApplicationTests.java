package com.codigo.patron_builder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatronBuilderApplicationTests {

	@Test
	void contextLoads() {
	}

}
