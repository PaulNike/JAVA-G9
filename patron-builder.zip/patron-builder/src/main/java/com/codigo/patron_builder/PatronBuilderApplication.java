package com.codigo.patron_builder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatronBuilderApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatronBuilderApplication.class, args);
	}

}
