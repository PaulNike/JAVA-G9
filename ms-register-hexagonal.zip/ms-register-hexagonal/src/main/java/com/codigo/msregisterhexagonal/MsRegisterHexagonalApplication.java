package com.codigo.msregisterhexagonal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsRegisterHexagonalApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsRegisterHexagonalApplication.class, args);
    }

}
