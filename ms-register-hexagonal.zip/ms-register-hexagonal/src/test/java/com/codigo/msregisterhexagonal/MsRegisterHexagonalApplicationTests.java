package com.codigo.msregisterhexagonal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsRegisterHexagonalApplicationTests {

    @Test
    void contextLoads() {
    }

}
