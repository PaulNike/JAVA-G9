package com.codigo.ms_seguridad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsSeguridadApplicationTests {

	@Test
	void contextLoads() {
	}

}
