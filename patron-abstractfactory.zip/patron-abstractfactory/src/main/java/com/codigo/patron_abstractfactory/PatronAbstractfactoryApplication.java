package com.codigo.patron_abstractfactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatronAbstractfactoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatronAbstractfactoryApplication.class, args);
	}

}
