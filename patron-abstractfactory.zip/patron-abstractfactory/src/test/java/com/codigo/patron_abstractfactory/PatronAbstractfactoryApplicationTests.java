package com.codigo.patron_abstractfactory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatronAbstractfactoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
